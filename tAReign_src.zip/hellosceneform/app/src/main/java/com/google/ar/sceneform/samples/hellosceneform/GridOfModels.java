package com.google.ar.sceneform.samples.hellosceneform;

/**
 * Created by laithabad on 11/20/2019.
 */

public class GridOfModels {
    private Integer[] grid;


    public GridOfModels(Integer[] grid) {
        this.grid = grid;
    }

    public Integer[] getGrid() {
        return grid;
    }

    public void setGrid(Integer[] grid) {
        this.grid = grid;
    }



}
